
let productList = []; // genero el arreglo donde se guardan los productos/articulos
let productShown = 0; // contador de productos mostrados
let productPerPage = 4; // cantidad de productos por carga

// Consumo de API con fetch y promesas
function apiProducts() {
   
   const articleCard = document.getElementById('product-container');
   
   if (!articleCard) return;

   articleCard.innerHTML = '<p>Cargando productos...</p>';

   fetch('https://dummyjson.com/products')
      .then( res => {
         if (!res.ok) {
            throw new Error(`Error HTTP: ${res.status}`);
         }
         return res.json();
      })
      .then( data => {
         productList = data.products || [];
         console.log(productList);
         articleCard.innerHTML = '';
         
         addProducts();
      })
      .catch( err => {
         console.error('Error al obtener productos:', err);
         articleCard.innerHTML = '<p>No se pudieron cargar los productos.</p>';
      });
}

function addProducts () {
   
   const articleCard = document.getElementById('product-container');
   const btnAdd = document.getElementById('mostrar-products');

   if (!articleCard) return;

   const nextProducts = productList.slice(productShown, productShown + productPerPage);
//                                     .slice(inicio = 0, hasta donde tomar = 4)         
   
// Guardar en memoria lo que construimos hasta decidir cargar dentro del DOM
   const fragment = document.createDocumentFragment();

   nextProducts.forEach( product => {

      const article = document.createElement('article');
      article.className = 'product-card';

      const imageUrl = (product.images && product.images[0]) || product.thumbnail || '';

      article.innerHTML = `
         <img src="${imageUrl}" alt="imagen de ${product.title}" loading="lazy" class="product-img">

         <div class="product-content">
         <span class="product-category">${product.category}</span>

         <h4 class="product-title">${product.title}</h4>

         <p class="product-description">${product.description}</p>

         <p class="product-price">
            <span>Precio: $</span>
            <span>${Number(product.price).toFixed(2)}</span>
         </p>

         <button type="button" class="product-button">Agregar al Carrito</button>
         </div>
      `;      
      fragment.appendChild(article);
  } );

  articleCard.appendChild(fragment);
  productShown += nextProducts.length;

   // Control de visibilidad y estado del botón
   if (btnAdd) {
      const sinMasProductos = ( productShown >= productList.length ); // TRUE O FALSE
      btnAdd.style.display = sinMasProductos ? 'none' : 'inline-block';
      btnAdd.disabled = sinMasProductos;
   } else {
      console.warn('No se encontró el botón con id="mostrar-products" en el DOM.');
   }
   
  // Notifica a products.js que hay nuevas tarjetas en el DOM
  document.dispatchEvent(new CustomEvent('products:loaded'));
}

// Espera a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', () => {

   const articleCard = document.getElementById('product-container');
   const btnAdd = document.getElementById('mostrar-products');

   if (articleCard) {
      apiProducts();
   }

   if (btnAdd) {
      btnAdd.style.display = 'none';
      btnAdd.addEventListener('click', () => {
         addProducts();
      });
   }
});

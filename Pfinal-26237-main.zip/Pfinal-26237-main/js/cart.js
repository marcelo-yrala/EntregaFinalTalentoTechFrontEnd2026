
// Actualiza o muestra los productos del carrito de compras
function handleAddToCart() {

   const articles = JSON.parse(localStorage.getItem('shoppingCard')) || [];
   let precioTotal = 0; 
   const carrito = document.getElementById('item-products');
   const checkoutButton = document.getElementById('checkout-button');

   const hasProducts = Array.isArray(articles) && articles.length > 0;

   if (checkoutButton) checkoutButton.hidden = !hasProducts;

   if (!hasProducts) {
      carrito.innerHTML = '<p>El carrito está vacío</p>';
      return;
   }

   const tabla = document.createElement('table');

   tabla.classList.add('name-class');

   let encabezado = `
            <thead>
               <tr>
                  <th>Cantidad</th>
                  <th>Producto</th>
                  <th>Precio</th>
               </tr>
            </thead>
   `;

   let cuerpo = '<tbody>';

   articles.forEach( article => {
      cuerpo += `
         <tr>
            <td>${article.count}</td>
            <td>${article.title}</td>
            <td>$${article.price}</td>
         </tr>
      `
      precioTotal += article.price * article.count;
   });

   cuerpo += '</tbody>';

   let pie = `
            <tfoot>
               <tr>
                  <th colspan="3">Total: $ ${precioTotal.toFixed(2)}</th>
               </tr>
            </tfoot>
   `;

   tabla.innerHTML = encabezado + cuerpo + pie;
   carrito.appendChild(tabla);
}

function finalizarCompra() {

   let articles = JSON.parse(localStorage.getItem('shoppingCard') || '[]');
   const checkoutButton = document.getElementById('checkout-button');
/*    
   const hasProducts = Array.isArray(articles) && articles.length > 0;

   if (checkoutButton) checkoutButton.hidden = !hasProducts;
 */
   // reduce(): recorrer un array y acumular sus elementos en un único valor final, indica el valor inicial
   const totalItems = articles.reduce((total, article) => total + article.count, 0);
   const totalPrice = articles.reduce(
      (total, article) => total + article.price * article.count, 0
   );

   const confirmed = confirm(
      `¿Confirmas la compra de ${totalItems} ${totalItems === 1 ? 'producto' : 'productos'} por $${totalPrice.toFixed(2)}?`
   );

   // Controlamos si el usuario Acepto/OK o no la ventana emergente
   if (!confirmed) return;

   localStorage.removeItem('shoppingCard');
   localStorage.removeItem('productCount');

   // recargar o refrescar la página web actual
   location.reload();
}

// Cargar dentro del DOM
document.addEventListener('DOMContentLoaded', () => {
   handleAddToCart();
   document.getElementById('checkout-button').addEventListener('click', finalizarCompra);
});
















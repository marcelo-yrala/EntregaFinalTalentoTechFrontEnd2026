/* 
let products = [
   {
      title: 'Producto 1',
      price: 123.99,
   },
   {
      title: 'Producto 2',
      price: 456.99,
   },
   {
      title: 'Producto 3',
      price: 789.99,
   }
];
 */


const articles = JSON.parse(localStorage.getItem('shoppingCard')) || [];
const counts = JSON.parse(localStorage.getItem('productCount')) || 0;      
let countP = parseInt(counts);

function updateCount() {
   document.querySelector('#count').textContent = countP !== 0 ? countP : '';
}

updateCount();

const productContainer = document.querySelector('#product-container');

productContainer.addEventListener('click', event => {

   const btnAdd = event.target.closest('.product-button');
   if (!btnAdd) return;

   const product = btnAdd.closest('.product-card');
   if (!product) return;

   const productTitle = product.querySelector('.product-title').textContent.trim();
   const productPrice = product.querySelector('.product-price span:last-child').textContent.trim();
   const existingItem = articles.find(item => item.title === productTitle);

   const productData = { 
      title: productTitle, 
      price: productPrice, 
      count: 1 

   };

   if (existingItem) {
      existingItem.count += 1;
   } else {
      articles.push(productData);
   }

   countP += 1;
   updateCount();
   
   localStorage.setItem('shoppingCard', JSON.stringify(articles));
   localStorage.setItem('productCount', JSON.stringify(countP));
});



